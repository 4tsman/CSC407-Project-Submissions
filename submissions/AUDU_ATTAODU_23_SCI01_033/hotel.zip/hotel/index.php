<?php require 'config.php';
if (!empty($_SESSION['uid'])) {
    $s = $pdo->prepare("SELECT COUNT(*) FROM reservations WHERE user_id=? AND status<>'cancelled' AND check_out>=CURDATE()");
    $s->execute([$_SESSION['uid']]); $upcoming = $s->fetchColumn();
}
include 'header.php'; ?>
<div class="hero">
  <h1>Welcome to Grand Hotel</h1>
  <p>Comfort, luxury and easy online booking.</p>
  <a class="btn" href="rooms.php">Find a Room</a>
  <?php if (empty($_SESSION['uid'])): ?><a class="btn" href="register.php">Create Account</a><?php endif; ?>
</div>
<?php if (!empty($_SESSION['uid'])): ?>
  <div class="card"><h2>Your Dashboard</h2><p>Hello, <?= e($_SESSION['name']) ?>. You have <b><?= (int)$upcoming ?></b> upcoming booking(s).</p>
  <a href="my_bookings.php">View my bookings</a></div>
<?php endif; ?>
<h2>Our Rooms</h2>
<div class="grid">
  <a class="tile pic pic-Single" href="rooms.php?type=Single"><span>Single Rooms</span></a>
  <a class="tile pic pic-Double" href="rooms.php?type=Double"><span>Double Rooms</span></a>
  <a class="tile pic pic-Suite" href="rooms.php?type=Suite"><span>Luxury Suites</span></a>
</div>
<h2>Why Book With Us</h2>
<div class="grid">
  <div class="card"><div class="icon">🔒</div><h3>Secure</h3><p>Your details are protected.</p></div>
  <div class="card"><div class="icon">📅</div><h3>Easy Booking</h3><p>Pick your dates and reserve in seconds.</p></div>
  <div class="card"><div class="icon">🛏️</div><h3>Comfortable Rooms</h3><p>Wi-Fi, AC and great service.</p></div>
</div>
<?php include 'footer.php';
