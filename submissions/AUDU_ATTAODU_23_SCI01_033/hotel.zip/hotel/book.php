<?php require 'config.php'; require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: rooms.php'); exit; }
check_csrf();
$room = (int)($_POST['room_id'] ?? 0); $in = $_POST['check_in'] ?? ''; $out = $_POST['check_out'] ?? '';
$d1 = DateTime::createFromFormat('Y-m-d', $in); $d2 = DateTime::createFromFormat('Y-m-d', $out);
$today = new DateTime('today');
if (!$d1 || !$d2 || $d1->format('Y-m-d') !== $in || $d2->format('Y-m-d') !== $out) $msg = 'Invalid dates.';
elseif ($d1 < $today) $msg = 'Check-in cannot be in the past.';
elseif ($d2 <= $d1) $msg = 'Check-out must be after check-in.';
else {
    $pdo->beginTransaction();
    $r = $pdo->prepare('SELECT price FROM rooms WHERE id=? FOR UPDATE');   // locks the room row
    $r->execute([$room]); $row = $r->fetch();
    if (!$row) { $pdo->rollBack(); $msg = 'Room not found.'; }
    else {
        // Double-booking check: any non-cancelled booking that overlaps these dates?
        $c = $pdo->prepare("SELECT COUNT(*) FROM reservations WHERE room_id=? AND status<>'cancelled' AND check_in<? AND check_out>?");
        $c->execute([$room, $out, $in]);
        if ($c->fetchColumn() > 0) { $pdo->rollBack(); $msg = 'Sorry, that room is already booked for those dates.'; }
        else {
            $nights = $d1->diff($d2)->days;
            $pdo->prepare('INSERT INTO reservations(user_id,room_id,check_in,check_out,total) VALUES(?,?,?,?,?)')
                ->execute([$_SESSION['uid'], $room, $in, $out, $nights * $row['price']]);
            $pdo->commit();
            $_SESSION['flash'] = 'Booking submitted. Awaiting confirmation by staff.';
            header('Location: my_bookings.php'); exit;
        }
    }
}
$_SESSION['flash'] = $msg; header('Location: rooms.php');
