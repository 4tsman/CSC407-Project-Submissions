<?php require 'config.php'; include 'header.php'; ?>
<h1>Security Measures</h1>
<div class="card"><ul>
<li><b>Password hashing:</b> passwords are stored with password_hash() (bcrypt), never as plain text.</li>
<li><b>SQL injection:</b> every query uses PDO prepared statements.</li>
<li><b>XSS:</b> all output is escaped with htmlspecialchars().</li>
<li><b>CSRF:</b> every form carries a secret token that is checked on the server.</li>
<li><b>Sessions:</b> HttpOnly + SameSite cookies, ID regenerated at login, 15-minute inactivity timeout, full logout.</li>
<li><b>Role-based access:</b> admin pages reject guests (HTTP 403); guests can only see and cancel their own bookings.</li>
<li><b>Input validation:</b> names, emails, passwords, dates and prices are validated on the server.</li>
<li><b>Brute-force protection:</b> login is locked for 5 minutes after 5 failed attempts.</li>
<li><b>Double-booking prevention:</b> a database transaction with a row lock and an overlap check.</li>
<li><b>Sensitive data:</b> database credentials come from environment variables; errors are logged, not shown to users; no card details are stored.</li>
</ul></div>
<?php include 'footer.php';
