# Hotel Reservation System

**Author:**AUDU ATTA-ODU GOODLUCK  
**Matric number:** 23/SCI01/033  
**Course:** CSC 407

## What it does
A web application for booking hotel rooms online. Guests search for rooms and book them; hotel staff (admin) manage rooms and reservations.

## Features
**Guest:**
- Register, log in and log out
- Search and filter rooms by dates, room type and maximum price
- Book a room and see the booking in "My Bookings"
- Cancel their own bookings

**Admin:**
- Dashboard with reservations, pending bookings, guests and confirmed revenue
- Confirm or cancel any reservation
- Add new rooms

**Main logic feature:** Double-booking prevention: a database transaction with a row lock checks that no other booking overlaps the chosen dates.

## Technology
PHP 8 (PDO), MySQL, HTML and CSS. Runs on XAMPP (Apache + MySQL).

## Security measures
- Passwords hashed with `password_hash()` (bcrypt)
- SQL injection protection: PDO prepared statements on every query
- XSS protection: all output escaped with `htmlspecialchars()`
- CSRF tokens on every form
- Secure sessions: HttpOnly and SameSite cookies, session ID regenerated at login, 15-minute inactivity timeout
- Role-based access control (admin pages return HTTP 403 for other users; users only see their own records)
- Server-side input validation
- Login lock for 5 minutes after 5 failed attempts
- Database credentials read from environment variables; errors are logged, not shown to users

These are also listed on the app's **Security** page.

## How to run it (XAMPP, Windows)
1. Install XAMPP and click **Start** next to **Apache** and **MySQL** in the XAMPP control panel.
2. Copy the `hotel` project folder into `C:\xampp\htdocs\`.
3. Open `http://localhost/phpmyadmin`, go to the **Import** tab, choose `schema.sql` and click **Import**. This creates the `hotel_db` database.
4. Open `http://localhost/hotel/setup.php` **once**. It creates the admin account and sample data. Then delete `setup.php`.
5. Open `http://localhost/hotel/`.

To use the app from a phone on the same Wi-Fi, open `http://YOUR-COMPUTER-IP/hotel/` (find the IP with `ipconfig`). For HTTPS on XAMPP use `https://localhost/hotel/` (accept the browser's self-signed certificate warning).

## Demo login
- Admin: `admin@hotel.com` / `Admin123` (can be changed in any real deployment)
- Guest: register a new account on the Register page

## Pictures
`images` folder (colored backgrounds show if missing).

## Deployment notes
The project runs on a local XAMPP server. Database settings are read from the environment variables `DB_HOST`, `DB_NAME`, `DB_USER` and `DB_PASS` (defaults match XAMPP), so no passwords are stored in the code. A live deployment would use HTTPS, a non-root database user, and backups of the database.

## Limitations
- Payments are not processed (no card details are collected).
- No email notifications.
- Designed and tested on a local XAMPP server.
